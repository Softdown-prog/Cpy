# Pixelhook Crawler

Ferramenta para rastreamento de sites, análise de SEO e verificação de links quebrados, com suporte a sitemap.xml e robots.txt.

## Execução

```bash
python crawler.py
```