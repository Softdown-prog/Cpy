
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import csv
from utils.sitemap_parser import get_urls_from_sitemap
from utils.robots_checker import is_allowed
from utils.seo_analysis import analyze_page

def executar_crawler(base_url, max_paginas=1700):
    visitados = set()
    a_visitar = get_urls_from_sitemap(base_url) or [base_url]
    resultado = []

    domain = urlparse(base_url).netloc

    while a_visitar and len(visitados) < max_paginas:
        url = a_visitar.pop(0)
        if url in visitados or urlparse(url).netloc != domain:
            continue
        if not is_allowed(url):
            continue
        try:
            r = requests.get(url, timeout=10)
            html = r.text
            dados = analyze_page(url, html)
            resultado.append(dados)
            soup = BeautifulSoup(html, "html.parser")

            for tag in soup.find_all("a", href=True):
                link = urljoin(url, tag["href"])
                if link.startswith(base_url) and link not in visitados:
                    a_visitar.append(link)

        except Exception as e:
            resultado.append({
                "url": url,
                "titulo": "",
                "descricao": "",
                "erro": str(e),
                "links_quebrados": []
            })

        visitados.add(url)

    with open("relatorio.csv", "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["url", "titulo", "descricao", "erro", "links_quebrados"])
        writer.writeheader()
        for row in resultado:
            writer.writerow(row)

    return resultado
