
import requests
from urllib.robotparser import RobotFileParser
from urllib.parse import urlparse

def is_allowed(url):
    parsed = urlparse(url)
    base = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    try:
        rp = RobotFileParser()
        rp.set_url(base)
        rp.read()
        return rp.can_fetch("*", url)
    except:
        return True
