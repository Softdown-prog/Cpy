
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import requests

def analyze_page(url, html):
    soup = BeautifulSoup(html, "html.parser")
    titulo = soup.title.string.strip() if soup.title else "Sem título"
    desc = soup.find("meta", attrs={"name": "description"})
    descricao = desc["content"].strip() if desc and "content" in desc.attrs else "Sem descrição"

    links_quebrados = []
    for tag in soup.find_all("a", href=True):
        link = urljoin(url, tag["href"])
        try:
            res = requests.head(link, timeout=5)
            if res.status_code >= 400:
                links_quebrados.append(link)
        except:
            links_quebrados.append(link)

    return {
        "url": url,
        "titulo": titulo,
        "descricao": descricao,
        "erro": "",
        "links_quebrados": "|".join(links_quebrados)
    }
