
import requests
from xml.etree import ElementTree

def get_urls_from_sitemap(base_url):
    sitemap_url = base_url.rstrip("/") + "/sitemap.xml"
    try:
        resp = requests.get(sitemap_url, timeout=5)
        tree = ElementTree.fromstring(resp.content)
        return [loc.text for loc in tree.findall(".//{*}loc")]
    except:
        return []
