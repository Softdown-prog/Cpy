
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def executar_crawler(base_url, max_paginas=1700):
    visitados = set()
    a_visitar = [base_url]
    resultado = []

    while a_visitar and len(visitados) < max_paginas:
        url = a_visitar.pop(0)
        if url in visitados or not url.startswith(base_url):
            continue

        try:
            resp = requests.get(url, timeout=10)
            html = resp.text
            soup = BeautifulSoup(html, 'html.parser')

            titulo = soup.title.string if soup.title else "Sem título"
            descricao_tag = soup.find("meta", attrs={"name": "description"})
            descricao = descricao_tag["content"] if descricao_tag else "Sem descrição"

            links_quebrados = []
            for tag in soup.find_all("a", href=True):
                link = urljoin(url, tag["href"])
                try:
                    r = requests.head(link, timeout=5)
                    if r.status_code >= 400:
                        links_quebrados.append(link)
                except:
                    links_quebrados.append(link)

            resultado.append({
                "url": url,
                "titulo": titulo,
                "descricao": descricao,
                "links_quebrados": links_quebrados
            })

            visitados.add(url)

            for tag in soup.find_all("a", href=True):
                link = urljoin(url, tag["href"])
                if link.startswith(base_url) and link not in visitados:
                    a_visitar.append(link)

        except Exception as e:
            resultado.append({
                "url": url,
                "erro": str(e)
            })

    return resultado
