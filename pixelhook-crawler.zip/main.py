
import os
from flask import Flask, request, jsonify
from crawler import executar_crawler

app = Flask(__name__)

@app.route("/executar", methods=["POST"])
def executar():
    data = request.json
    url = data.get("url")
    resultado = executar_crawler(url)
    return jsonify(resultado)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
